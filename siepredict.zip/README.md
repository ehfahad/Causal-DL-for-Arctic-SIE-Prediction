# hubtooltemplatepublic
Directory structure for HUB tools

.keep files are present to force git to track initially empty directories.
Should the directories become populated the .keep file can be removed.
